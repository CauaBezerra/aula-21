const Engine = Matter.Engine;
const World = Matter.World;
const Bodies = Matter.Bodies;

let engine;
let world;

var ground;
var left;
var right;
var top_wall;
var bola;
var seta_cima, seta_direita;

function setup() {
  createCanvas(400,400);
  engine = Engine.create();
  world = engine.world;

  seta_cima = createImg("up.png");
  seta_direita = createImg("right.png");
  seta_cima.position(20,30);
  seta_direita.position(220,30);
  seta_cima.size(50,50);
  seta_direita.size(50,50);
  seta_cima.mouseClicked(f_vertical);
  seta_direita.mouseClicked(f_horizontal);

  ground =new Ground(200,390,400,20);
  right = new Ground(390,200,20,400);
  left = new Ground(10,200,20,400);
  top_wall = new Ground(200,10,400,20);

  var bola_opcoes = {
    restitution:0.95
  }

  bola = Bodies.circle(200,100,20,bola_opcoes);
  World.add(world,bola);
 
  rectMode(CENTER);
  ellipseMode(RADIUS);
}

function draw() 
{
  background(51);
  ground.show();
  top_wall.show();
  left.show();
  right.show();

  ellipse(bola.position.x, bola.position.y,20);

  Engine.update(engine);
}

function f_horizontal(){
  Matter.Body.applyForce(bola, {x:0,y:0}, {x:0.05,y:0});
}

function f_vertical(){
  Matter.Body.applyForce(bola, {x:0,y:0}, {x:0,y:-0.05});
}

